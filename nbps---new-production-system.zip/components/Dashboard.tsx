import React from 'react';
import { RawMaterial, OrderItem } from '../types';
import { Archive, ShoppingCart, Activity } from 'lucide-react';

interface DashboardProps {
  inventory: RawMaterial[];
  orders: OrderItem[];
}

const StatCard = ({ title, value, icon: Icon, colorClass }: any) => (
  <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center space-x-4">
    <div className={`p-3 rounded-full ${colorClass} text-white`}>
      <Icon size={24} />
    </div>
    <div>
      <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{title}</p>
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{value}</h3>
    </div>
  </div>
);

export const Dashboard: React.FC<DashboardProps> = ({ inventory, orders }) => {
  const totalWeight = inventory.reduce((acc, item) => acc + item.weight, 0).toFixed(1);
  const pendingOrders = orders.filter(o => !o.isFulfilled).length;
  const fulfilledOrders = orders.filter(o => o.isFulfilled).length;
  const efficiencyRate = orders.length > 0 ? ((fulfilledOrders / orders.length) * 100).toFixed(1) : '0.0';

  return (
    <div className="space-y-6 animate-fade-in">
      <h2 className="text-3xl font-bold text-gray-800 dark:text-white tracking-tight">Production Overview</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          title="Total Inventory (kg)" 
          value={totalWeight} 
          icon={Archive} 
          colorClass="bg-biroea-500" 
        />
        <StatCard 
          title="Pending Orders" 
          value={pendingOrders} 
          icon={ShoppingCart} 
          colorClass="bg-orange-500" 
        />
        <StatCard 
          title="Fulfillment Rate (%)" 
          value={efficiencyRate} 
          icon={Activity} 
          colorClass="bg-emerald-500" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
          <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Recent Inventory</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-gray-500 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300">
                <tr>
                  <th className="px-4 py-3">Batch</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Width</th>
                  <th className="px-4 py-3">Weight</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {inventory.slice(0, 5).map(item => (
                  <tr key={item.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{item.batchNumber}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-300">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${item.isRemnant ? 'bg-orange-100 text-orange-800' : 'bg-green-100 text-green-800'}`}>
                        {item.isRemnant ? 'Remnant' : 'Master'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{item.width} mm</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{item.weight} kg</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
           <h3 className="text-lg font-semibold mb-4 text-gray-800 dark:text-white">Recent Orders</h3>
           <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-gray-500 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300">
                <tr>
                  <th className="px-4 py-3">Customer</th>
                  <th className="px-4 py-3">Req. Width</th>
                  <th className="px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                {orders.slice(0, 5).map(item => (
                  <tr key={item.id} className="border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                    <td className="px-4 py-3 font-medium text-gray-900 dark:text-white">{item.customerName}</td>
                    <td className="px-4 py-3 text-gray-600 dark:text-gray-300">{item.requiredWidth} mm</td>
                    <td className="px-4 py-3">
                       <span className={`px-2 py-1 rounded-full text-xs font-semibold ${item.isFulfilled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                        {item.isFulfilled ? 'Done' : 'Pending'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};