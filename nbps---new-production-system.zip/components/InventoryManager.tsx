import React, { useState } from 'react';
import { RawMaterial } from '../types';
import { Plus, Trash2, Search } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';

interface InventoryManagerProps {
  inventory: RawMaterial[];
  onAdd: (item: RawMaterial) => void;
  onDelete: (id: string) => void;
}

export const InventoryManager: React.FC<InventoryManagerProps> = ({ inventory, onAdd, onDelete }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form State
  const [formData, setFormData] = useState<Partial<RawMaterial>>({
    batchNumber: '',
    materialType: 'PVC',
    width: 1000,
    weight: 0,
    isRemnant: false
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.batchNumber || !formData.width || !formData.weight) return;

    const newItem: RawMaterial = {
      id: uuidv4(),
      batchNumber: formData.batchNumber,
      materialType: formData.materialType || 'PVC',
      width: Number(formData.width),
      weight: Number(formData.weight),
      isRemnant: formData.isRemnant || false,
      entryDate: new Date().toISOString()
    };

    onAdd(newItem);
    setIsModalOpen(false);
    setFormData({ batchNumber: '', materialType: 'PVC', width: 1000, weight: 0, isRemnant: false });
  };

  const filteredInventory = inventory.filter(item => 
    item.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.materialType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6 h-full flex flex-col">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-3xl font-bold text-gray-800 dark:text-white">Inventory</h2>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-biroea-600 hover:bg-biroea-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-sm transition-all"
        >
          <Plus size={20} />
          <span>Add Stock</span>
        </button>
      </div>

      <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex items-center gap-2">
        <Search className="text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="Search by batch or type..." 
          className="bg-transparent border-none focus:ring-0 text-gray-700 dark:text-white w-full"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="flex-1 overflow-auto bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-500 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300 sticky top-0">
            <tr>
              <th className="px-6 py-4">Batch #</th>
              <th className="px-6 py-4">Type</th>
              <th className="px-6 py-4">Category</th>
              <th className="px-6 py-4">Dimensions</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
            {filteredInventory.map(item => (
              <tr key={item.id} className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <td className="px-6 py-4 font-medium text-gray-900 dark:text-white">{item.batchNumber}</td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-300">{item.materialType}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${item.isRemnant ? 'bg-orange-100 text-orange-800 border border-orange-200' : 'bg-green-100 text-green-800 border border-green-200'}`}>
                    {item.isRemnant ? 'Remnant' : 'Master Roll'}
                  </span>
                </td>
                <td className="px-6 py-4 text-gray-600 dark:text-gray-300">
                  W: <span className="font-bold">{item.width}mm</span> • {item.weight}kg
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => onDelete(item.id)}
                    className="text-red-500 hover:text-red-700 p-2 rounded-full hover:bg-red-50 dark:hover:bg-gray-600 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
            {filteredInventory.length === 0 && (
              <tr>
                <td colSpan={5} className="text-center py-8 text-gray-500 dark:text-gray-400">No inventory found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl p-6 w-full max-w-md m-4">
            <h3 className="text-xl font-bold mb-4 text-gray-900 dark:text-white">Add New Stock</h3>
            <form onSubmit={handleAdd} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Batch Number</label>
                <input 
                  required 
                  type="text" 
                  className="w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white focus:ring-biroea-500 focus:border-biroea-500"
                  value={formData.batchNumber}
                  onChange={e => setFormData({...formData, batchNumber: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Width (mm)</label>
                  <input 
                    required 
                    type="number" 
                    className="w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    value={formData.width}
                    onChange={e => setFormData({...formData, width: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Weight (kg)</label>
                  <input 
                    required 
                    type="number" 
                    className="w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                    value={formData.weight}
                    onChange={e => setFormData({...formData, weight: Number(e.target.value)})}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Material Type</label>
                <select 
                  className="w-full rounded-lg border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white"
                  value={formData.materialType}
                  onChange={e => setFormData({...formData, materialType: e.target.value})}
                >
                  <option value="PVC-A">PVC-A</option>
                  <option value="PVC-B">PVC-B</option>
                  <option value="ALU-FOIL">ALU-FOIL</option>
                  <option value="PAPER">PAPER</option>
                </select>
              </div>
              <div className="flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="isRemnant"
                  className="rounded text-biroea-600 focus:ring-biroea-500 dark:bg-gray-700 dark:border-gray-600"
                  checked={formData.isRemnant}
                  onChange={e => setFormData({...formData, isRemnant: e.target.checked})}
                />
                <label htmlFor="isRemnant" className="text-sm text-gray-700 dark:text-gray-300">Is this a Remnant (Offcut)?</label>
              </div>
              
              <div className="flex gap-3 mt-6 pt-4 border-t dark:border-gray-700">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 px-4 py-2 text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-lg transition-colors"
                >
                  Cancel
                </button>
                <button 
                  type="submit" 
                  className="flex-1 px-4 py-2 bg-biroea-600 hover:bg-biroea-700 text-white rounded-lg transition-colors"
                >
                  Save Stock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};