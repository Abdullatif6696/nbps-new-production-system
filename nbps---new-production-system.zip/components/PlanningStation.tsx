import React, { useState, useMemo } from 'react';
import { RawMaterial, OrderItem, OptimizationPlan } from '../types';
import { OptimizerEngine } from '../services/optimizer';
import { K_TRIM_MARGIN, K_BLADE_THICKNESS } from '../constants';
import { Play, FileDown, CheckCircle, Scissors, CheckSquare, Square, Loader2 } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface PlanningStationProps {
  inventory: RawMaterial[];
  orders: OrderItem[];
  onExecute: (plan: OptimizationPlan) => void;
}

export const PlanningStation: React.FC<PlanningStationProps> = ({ inventory, orders, onExecute }) => {
  const [selectedOrderIds, setSelectedOrderIds] = useState<Set<string>>(new Set());
  const [currentPlan, setCurrentPlan] = useState<OptimizationPlan | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);

  const pendingOrders = useMemo(() => orders.filter(o => !o.isFulfilled), [orders]);

  const isAllSelected = useMemo(() => {
    return pendingOrders.length > 0 && pendingOrders.every(o => selectedOrderIds.has(o.id));
  }, [pendingOrders, selectedOrderIds]);

  const toggleOrder = (id: string) => {
    const newSet = new Set(selectedOrderIds);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelectedOrderIds(newSet);
    setCurrentPlan(null);
  };

  const handleSelectAll = () => {
    if (isAllSelected) {
      setSelectedOrderIds(new Set());
    } else {
      const allIds = pendingOrders.map(o => o.id);
      setSelectedOrderIds(new Set(allIds));
    }
    setCurrentPlan(null);
  };

  const handleCalculate = () => {
    const selected = pendingOrders.filter(o => selectedOrderIds.has(o.id));
    const plan = OptimizerEngine.calculatePlan(selected, inventory);
    setCurrentPlan(plan);
    if (!plan) {
      alert("No suitable roll found for this combination of orders.");
    }
  };

  const handleExecuteClick = async () => {
    if (!currentPlan) return;
    setIsExecuting(true);
    // Small delay to allow UI to update to loading state
    setTimeout(() => {
      onExecute(currentPlan);
      setIsExecuting(false);
    }, 100);
  };

  const handleExportPDF = async () => {
    const element = document.getElementById('report-export-area');
    if (!element) return;

    setIsGeneratingPdf(true);

    try {
      // Use html2canvas with onclone to force light mode styles for the PDF
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff', // White background for PDF
        onclone: (clonedDoc) => {
          const clonedElement = clonedDoc.getElementById('report-export-area');
          if (clonedElement) {
            // Force text color to black for printing readability
            clonedElement.style.color = '#000000';
            clonedElement.style.backgroundColor = '#ffffff';
            
            // Force all child text elements to be black
            const allElements = clonedElement.querySelectorAll('*');
            allElements.forEach((el) => {
               if (el instanceof HTMLElement) {
                 el.style.color = '#000000';
                 el.style.borderColor = '#e5e7eb'; // Light gray borders
               }
            });
          }
        }
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'mm',
        format: 'a4'
      });

      const pdfWidth = pdf.internal.pageSize.getWidth();
      const imgProps = pdf.getImageProperties(imgData);
      const imgHeight = (imgProps.height * pdfWidth) / imgProps.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, imgHeight);
      pdf.save(`Production_Plan_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (error) {
      console.error("PDF Export failed:", error);
      alert("Failed to export PDF. Please try again.");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-full gap-6">
      {/* LEFT: Selection Panel (No Print) */}
      <div className="w-full lg:w-1/3 bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col no-print">
        <div className="p-4 border-b dark:border-gray-700">
          <div className="flex justify-between items-center mb-1">
            <h3 className="font-bold text-gray-800 dark:text-white flex items-center gap-2">
              <Scissors className="text-biroea-500" size={20} />
              Select Orders
            </h3>
            {pendingOrders.length > 0 && (
              <button 
                type="button"
                onClick={handleSelectAll}
                className="text-xs font-medium text-biroea-600 dark:text-biroea-400 hover:text-biroea-700 flex items-center gap-1"
              >
                {isAllSelected ? <CheckSquare size={16} /> : <Square size={16} />}
                {isAllSelected ? "Deselect All" : "Select All"}
              </button>
            )}
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400">Check orders to include in this run.</p>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {pendingOrders.length === 0 ? (
            <div className="p-4 text-center text-gray-400 text-sm">No pending orders.</div>
          ) : (
            <div className="space-y-2">
              {pendingOrders.map(order => (
                <div 
                  key={order.id}
                  onClick={() => toggleOrder(order.id)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${selectedOrderIds.has(order.id) ? 'border-biroea-500 bg-biroea-50 dark:bg-biroea-900/20' : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'}`}
                >
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800 dark:text-white">{order.customerName}</span>
                    <input 
                      type="checkbox" 
                      checked={selectedOrderIds.has(order.id)} 
                      readOnly 
                      className="rounded text-biroea-600 focus:ring-biroea-500"
                    />
                  </div>
                  <div className="flex justify-between mt-1 text-xs text-gray-500 dark:text-gray-400">
                    <span>Width: {order.requiredWidth}mm</span>
                    <span>{order.targetWeight}kg</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="p-4 border-t dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50 rounded-b-xl">
           <button 
            type="button"
            onClick={handleCalculate}
            disabled={selectedOrderIds.size === 0}
            className="w-full bg-biroea-600 disabled:bg-gray-400 hover:bg-biroea-700 text-white font-semibold py-3 rounded-lg shadow-md transition-all flex justify-center items-center gap-2"
          >
            <Play size={18} fill="currentColor" />
            Compute Best Fit
          </button>
        </div>
      </div>

      {/* RIGHT: Visualizer & Results */}
      <div className="w-full lg:w-2/3 flex flex-col gap-6">
        
        {/* Visualization Canvas */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700 p-6 flex-1 min-h-[400px] flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-gray-800 dark:text-white text-xl">Optimization Result</h3>
            {currentPlan && (
              <div className="flex gap-2 no-print">
                 <button 
                  type="button"
                  onClick={handleExportPDF} 
                  disabled={isGeneratingPdf}
                  className="px-3 py-1.5 text-sm bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded text-gray-700 dark:text-gray-200 flex items-center gap-2 disabled:opacity-50"
                 >
                   {isGeneratingPdf ? <Loader2 size={16} className="animate-spin" /> : <FileDown size={16} />}
                   {isGeneratingPdf ? "Generating..." : "Export PDF"}
                 </button>
                 <button 
                  type="button"
                  onClick={handleExecuteClick}
                  disabled={isExecuting}
                  className="px-3 py-1.5 text-sm bg-green-600 hover:bg-green-700 rounded text-white flex items-center gap-2 shadow-sm disabled:opacity-70 disabled:cursor-not-allowed"
                 >
                   {isExecuting ? <Loader2 size={16} className="animate-spin" /> : <CheckCircle size={16} />} 
                   {isExecuting ? "Processing..." : "Confirm & Execute"}
                 </button>
              </div>
            )}
          </div>

          {!currentPlan ? (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 border-2 border-dashed border-gray-200 dark:border-gray-700 rounded-xl">
              <Scissors className="w-16 h-16 mb-4 opacity-20" />
              <p>Select orders and click "Compute" to see the plan.</p>
            </div>
          ) : (
            <div id="report-export-area" className="flex-1 flex flex-col gap-8 animate-fade-in p-4 bg-white dark:bg-gray-800">
              {/* Report Header */}
              <div className="mb-4 border-b dark:border-gray-700 pb-4">
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Production Cut Report</h1>
                <div className="flex gap-4 text-sm text-gray-500 dark:text-gray-400 mt-1">
                   <p>Date: {new Date().toLocaleDateString()}</p>
                   <p>Job ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</p>
                </div>
              </div>

              {/* Stats Bar */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg border border-blue-100 dark:border-blue-800">
                  <span className="text-xs text-blue-600 dark:text-blue-300 uppercase font-bold">Selected Roll</span>
                  <div className="font-mono text-lg font-semibold text-blue-900 dark:text-blue-100">{currentPlan.selectedRoll.batchNumber}</div>
                  <div className="text-xs text-blue-500 dark:text-blue-400">{currentPlan.selectedRoll.width}mm Width</div>
                </div>
                <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg border border-green-100 dark:border-green-800">
                  <span className="text-xs text-green-600 dark:text-green-300 uppercase font-bold">Efficiency</span>
                  <div className="font-mono text-lg font-semibold text-green-900 dark:text-green-100">{currentPlan.efficiency.toFixed(1)}%</div>
                  <div className="text-xs text-green-500 dark:text-green-400">Utilization</div>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg border border-purple-100 dark:border-purple-800">
                  <span className="text-xs text-purple-600 dark:text-purple-300 uppercase font-bold">Total Cuts</span>
                  <div className="font-mono text-lg font-semibold text-purple-900 dark:text-purple-100">{currentPlan.cuts.length}</div>
                  <div className="text-xs text-purple-500 dark:text-purple-400">Orders</div>
                </div>
                <div className="bg-red-50 dark:bg-red-900/20 p-3 rounded-lg border border-red-100 dark:border-red-800">
                  <span className="text-xs text-red-600 dark:text-red-300 uppercase font-bold">Waste (Offcut)</span>
                  <div className="font-mono text-lg font-semibold text-red-900 dark:text-red-100">{currentPlan.wasteWidth.toFixed(1)}mm</div>
                  <div className="text-xs text-red-500 dark:text-red-400">Remaining</div>
                </div>
              </div>

              {/* The Visualizer (SVG) */}
              <div className="border dark:border-gray-700 rounded-lg p-6 bg-gray-50 dark:bg-gray-900 overflow-x-auto">
                <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-4 uppercase tracking-wider">Visual Cut Guide</h4>
                <div className="min-w-[600px]">
                  <RollVisualizer plan={currentPlan} />
                </div>
              </div>

              {/* Blade Table */}
              <div className="mt-4">
                 <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2 uppercase tracking-wider">Blade Configuration</h4>
                 <div className="overflow-hidden border dark:border-gray-700 rounded-lg">
                   <table className="w-full text-sm text-left">
                     <thead className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300">
                       <tr>
                         <th className="px-4 py-2 border-b dark:border-gray-700">Seq</th>
                         <th className="px-4 py-2 border-b dark:border-gray-700">Customer</th>
                         <th className="px-4 py-2 border-b dark:border-gray-700">Width</th>
                         <th className="px-4 py-2 border-b dark:border-gray-700">Blade Position (from left)</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-gray-100 dark:divide-gray-700 text-gray-800 dark:text-gray-200">
                       {currentPlan.cuts.map((cut, idx) => (
                         <tr key={idx} className="bg-white dark:bg-gray-800">
                           <td className="px-4 py-2 font-mono">{idx + 1}</td>
                           <td className="px-4 py-2">{cut.customerName}</td>
                           <td className="px-4 py-2">{cut.requiredWidth}mm</td>
                           <td className="px-4 py-2 font-mono font-bold text-biroea-600 dark:text-biroea-400">{currentPlan.bladePositions[idx]}mm</td>
                         </tr>
                       ))}
                     </tbody>
                   </table>
                 </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// SVG Visualizer Component
const RollVisualizer: React.FC<{ plan: OptimizationPlan }> = ({ plan }) => {
  const totalWidth = plan.selectedRoll.width;
  const svgWidth = 800;
  const scale = svgWidth / totalWidth;
  const height = 120;
  const trimPx = K_TRIM_MARGIN * scale;
  let currentX = K_TRIM_MARGIN;

  return (
    <svg width="100%" viewBox={`0 0 ${svgWidth} ${height + 40}`} className="w-full">
      <rect x="0" y="20" width={svgWidth} height={height} fill="#e5e7eb" rx="4" />
      <text x="5" y="15" fontSize="10" fill="#6b7280">0mm</text>
      <text x={svgWidth - 30} y="15" fontSize="10" fill="#6b7280">{totalWidth}mm</text>

      <rect x="0" y="20" width={trimPx} height={height} fill="url(#diagonalHatch)" stroke="red" strokeWidth="1" opacity="0.5" />
      
      {plan.cuts.map((cut, i) => {
        const widthPx = cut.requiredWidth * scale;
        const xPx = currentX * scale;
        const isLast = i === plan.cuts.length - 1;
        
        const rect = (
          <g key={cut.id}>
             <rect 
              x={xPx + (i > 0 ? (K_BLADE_THICKNESS * scale) : 0)} 
              y="20" 
              width={widthPx} 
              height={height} 
              fill={i % 2 === 0 ? '#3b82f6' : '#60a5fa'}
              stroke="white"
              strokeWidth="1"
            />
            <text x={xPx + widthPx/2} y={height / 2 + 20} textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">
              {cut.customerName.substring(0, 10)}
            </text>
            <text x={xPx + widthPx/2} y={height / 2 + 35} textAnchor="middle" fill="white" fontSize="10" opacity="0.9">
              {cut.requiredWidth}mm
            </text>
             <line 
              x1={plan.bladePositions[i] * scale} 
              y1="10" 
              x2={plan.bladePositions[i] * scale} 
              y2={height + 30} 
              stroke="#ef4444" 
              strokeWidth="2" 
              strokeDasharray="4 2"
            />
            <text x={plan.bladePositions[i] * scale} y={height + 40} textAnchor="middle" fill="#ef4444" fontSize="10" fontWeight="bold">
              {plan.bladePositions[i]}
            </text>
          </g>
        );
        
        currentX += (i > 0 ? K_BLADE_THICKNESS : 0) + cut.requiredWidth;
        if (isLast) currentX += K_BLADE_THICKNESS;
        
        return rect;
      })}

      <rect x={svgWidth - trimPx} y="20" width={trimPx} height={height} fill="url(#diagonalHatch)" stroke="red" strokeWidth="1" opacity="0.5" />

      {plan.wasteWidth > 0 && (
        <rect 
          x={(totalWidth - K_TRIM_MARGIN - plan.wasteWidth) * scale} 
          y="20" 
          width={plan.wasteWidth * scale} 
          height={height} 
          fill="#fbbf24" 
          opacity="0.3"
        />
      )}

      <defs>
        <pattern id="diagonalHatch" width="10" height="10" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
          <line x1="0" y1="0" x2="0" y2="10" style={{stroke:'red', strokeWidth:1}} />
        </pattern>
      </defs>
    </svg>
  );
};