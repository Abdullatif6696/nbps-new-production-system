import { RawMaterial, OrderItem, OptimizationPlan } from '../types';
import { K_BLADE_THICKNESS, K_TRIM_MARGIN } from '../constants';

export class OptimizerEngine {
  /**
   * Calculates the best production plan for a selected list of orders
   * against the available inventory.
   */
  static calculatePlan(
    selectedOrders: OrderItem[],
    inventory: RawMaterial[]
  ): OptimizationPlan | null {
    if (selectedOrders.length === 0 || inventory.length === 0) return null;

    // 1. Sort Inventory: Remnants first (asc width), then Master Rolls (asc width to use smallest possible fit)
    // The prompt asked for: "Remnant (Smallest suitable width first), then Master Rolls".
    const sortedInventory = [...inventory]
      .filter(item => item.width > 0) // Sanity check
      .sort((a, b) => {
        if (a.isRemnant && !b.isRemnant) return -1;
        if (!a.isRemnant && b.isRemnant) return 1;
        return a.width - b.width; // Smallest width first within category
      });

    // 2. Sort Orders: Descending by width (Widest first - Best Fit Decreasing variant)
    const sortedOrders = [...selectedOrders].sort((a, b) => b.requiredWidth - a.requiredWidth);

    // 3. Algorithm: Find the first roll that can fit at least the widest order, 
    // and then try to pack as many other orders as possible into it.
    
    // Simple Greedy Approach:
    // Iterate through rolls. For each roll, try to pack the sorted orders.
    // Score the plan by waste minimization (or max width usage).
    
    let bestPlan: OptimizationPlan | null = null;

    for (const roll of sortedInventory) {
      const availableWidth = roll.width - (2 * K_TRIM_MARGIN);
      
      if (availableWidth <= 0) continue;

      let currentUsedWidth = 0;
      let currentCuts: OrderItem[] = [];
      let bladePositions: number[] = [];
      let currentPos = K_TRIM_MARGIN; // Start after left trim

      // Try to fit orders
      for (const order of sortedOrders) {
        // Calculate needed width: Order Width + Blade (unless it's the last one, but we account for blade after every cut for simplicity or check)
        // Strictly: Blade is needed between cuts. 
        // Logic: Total Used = Sum(Orders) + (N-1 * Blade)
        // Incremental logic:
        
        const isFirst = currentCuts.length === 0;
        const additionalBlade = isFirst ? 0 : K_BLADE_THICKNESS;
        const widthNeeded = order.requiredWidth + additionalBlade;

        if (currentUsedWidth + widthNeeded <= availableWidth) {
          currentCuts.push(order);
          currentUsedWidth += widthNeeded;
          
          // Blade Position:
          // If first cut: Position is Trim + OrderWidth
          // Next cut: PrevPosition + Blade + OrderWidth
          const cutEndPos = currentPos + additionalBlade + order.requiredWidth;
          bladePositions.push(cutEndPos);
          currentPos = cutEndPos;
        }
      }

      if (currentCuts.length > 0) {
        const waste = availableWidth - currentUsedWidth;
        const efficiency = (currentUsedWidth / availableWidth) * 100;
        
        // Strategy: Select the first valid plan that accommodates the largest order (highest priority)
        // Or select the plan with highest efficiency.
        // Prompt implies finding *a* plan. 
        // Let's prioritize efficiency.
        
        const plan: OptimizationPlan = {
          rollId: roll.id,
          selectedRoll: roll,
          cuts: currentCuts,
          bladePositions,
          wasteWidth: waste,
          usedWidth: currentUsedWidth,
          efficiency
        };

        if (!bestPlan || plan.efficiency > bestPlan.efficiency) {
          bestPlan = plan;
        }
      }
    }

    return bestPlan;
  }
}