import { RawMaterial, OrderItem, ThemeMode } from '../types';
import { MOCK_INVENTORY, MOCK_ORDERS } from '../constants';

const KEYS = {
  INVENTORY: 'nbps_inventory',
  ORDERS: 'nbps_orders',
  THEME: 'nbps_theme',
};

export const StorageService = {
  getInventory: (): RawMaterial[] => {
    const data = localStorage.getItem(KEYS.INVENTORY);
    return data ? JSON.parse(data) : MOCK_INVENTORY;
  },

  saveInventory: (inventory: RawMaterial[]) => {
    localStorage.setItem(KEYS.INVENTORY, JSON.stringify(inventory));
  },

  getOrders: (): OrderItem[] => {
    const data = localStorage.getItem(KEYS.ORDERS);
    return data ? JSON.parse(data) : MOCK_ORDERS;
  },

  saveOrders: (orders: OrderItem[]) => {
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
  },

  getTheme: (): ThemeMode => {
    return (localStorage.getItem(KEYS.THEME) as ThemeMode) || 'light';
  },

  saveTheme: (theme: ThemeMode) => {
    localStorage.setItem(KEYS.THEME, theme);
  }
};